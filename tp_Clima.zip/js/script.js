const apiKey = "9e122cd782b2d0333f5fe4e7fa192062";

// Función para obtener el clima por ciudad
function obtenerClimaPorCiudad(ciudad) {
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${ciudad}&appid=${apiKey}&lang=es&units=metric`;

    axios.get(url)
        .then(response => {
            mostrarClima(response.data);
        })
        .catch(error => {
            alert("Error al obtener los datos: " + error);
        });
}

// Función para obtener el clima por coordenadas
function obtenerClimaPorCoordenadas(lat, lon) {
    const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&lang=es&units=metric`;

    axios.get(url)
        .then(response => {
            mostrarClima(response.data);
        })
        .catch(error => {
            alert("Error al obtener los datos: " + error);
        });
}

// Función para mostrar el clima
function mostrarClima(data) {
    document.getElementById('cityName').innerText = `Clima en ${data.name}, ${data.sys.country}`;
    
    document.getElementById('weatherDescription').innerText = `Estado: ${data.weather[0].description}`;
   
    document.getElementById('temperature').innerText = `Temperatura: ${data.main.temp} °C`;

    let imagenClima = "";
    let descripcion = data.weather[0].main.toLowerCase();

    if (descripcion.includes("clear")) {
        imagenClima = "img/soleado.jpg"; 
    } else if (descripcion.includes("clouds")) {
        imagenClima = "img/nublado.jpg"; 
    } else if (descripcion.includes("rain")) {
        imagenClima = "img/lluvioso.jpg"; 
    } else if (descripcion.includes("snow")) {
        imagenClima = "img/nieve.jpg";
    }    
    
    document.getElementById('weatherImage').src = imagenClima;
    document.getElementById('weatherResult').style.display = 'block';
}

// Acción del botón
document.getElementById('getWeather').addEventListener('click', () => {
    const ciudad = document.getElementById('city').value.trim();
    const latitud = document.getElementById('latitude').value.trim();
    const longitud = document.getElementById('longitude').value.trim();

    if (ciudad) {
        obtenerClimaPorCiudad(ciudad);
    } else if (latitud && longitud) {
        obtenerClimaPorCoordenadas(latitud, longitud);
    } else {
        alert("Por favor ingresa una ciudad o coordenadas.");
    }
});
